New Relic PHP Agent

For installation instructions, INI file settings, 
and API descriptions please see the online FAQ at:
    https://docs.newrelic.com/docs/agents/php-agent/getting-started/introduction-new-relic-php/

For license and copyright, see LICENSE.

For support, contact us at https://support.newrelic.com for assistance.
